#!/bin/sh
make
./myfork ./mac/p1 ./mac/p2 ./mac/p3 ./mac/p4
make clean
