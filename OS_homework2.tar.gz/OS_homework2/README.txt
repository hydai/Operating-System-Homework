There are three parts for the project 2.

RiverAndFrog:
    How to install:
        1. type `make`
        2. ./Game
    Detail:
        Woods have random length and speed.
