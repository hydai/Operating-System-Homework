#include "RiverAndFrog.h"

int main(int argc, char *argv[])
{
    GameStage *game = new GameStage();
    game->exec();
    return 0;
}
