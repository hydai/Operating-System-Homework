How to run my program:
	1) `make`
	2) `./vm`
In bonus mode, please use the following command:
	1) `make bonus`
	2) `./mvm`
If you want to run in debug mode:
	1) `make debug`
	2) `./vm-debug`

Please make sure that data.bin is in the same folder.
Otherwise, modify the dafination of DATAFILE in the main.cu.
