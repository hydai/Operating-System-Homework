How to run my program:
	1) `make`
	2) `./fs`

Please make sure that data.bin is in the same folder.
Otherwise, modify the dafination of DATAFILE in the main.cu.
