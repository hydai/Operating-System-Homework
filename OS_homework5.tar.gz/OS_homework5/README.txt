For sample testing:
	chmod 755 ./run.sh
	./run.sh
The formal rules:
	make
	./mkdev.sh 251 0
	./test
	./rmdev
	make clean
