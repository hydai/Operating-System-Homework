make
sudo ./mkdev.sh 251 0
./test
sudo ./rmdev.sh
make clean

